import 'package:flutter/material.dart';
import 'package:ourpromise/rootpage.dart';


void main() {
  runApp(
    new MaterialApp(
      title: 'Google Sign In',
      home: new RootPage(),
    ),
  );
}
