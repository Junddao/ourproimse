import 'package:flutter/material.dart';
import 'package:ourpromise/loginpage.dart';
// import 'package:ourpromise/tabpage.dart';

class RootPage extends StatelessWidget {
  bool isLogin = false;
  @override
  Widget build(BuildContext context) {
    return LoginPage();
  }
}